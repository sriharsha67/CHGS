var reviews=0;
$(document).ready(function(){
    $('select').material_select();   
    $('.modal').modal();
    $(".button-collapse").sideNav();
    $('textarea#prof-status,textarea#prof-about').characterCounter();
    //$('#dob').datepicker({ dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true });

    /*M.updateTextFields();*/
    
    
    $('#up_profile_image').bind('change', function(e) {
      var data = e.originalEvent.target.files[0];
      // and then ...
      console.log(data.size + "is my file's size");
      // or something more useful ...
      if(data.size > 2048) {
          $('#up_profile_image').html();
        alert('Image size must be less than 2 MB.');
      }
    });
    
    });

          
//Searcbar
          
  $('.sj-searchbar li input').keyup(function()
    {
       if($(this).val().length>0)
        {
        $.get('http://localhost/samajic/index.php/User/search/'+$(this).val(),function(d)
        {
        if(d.length>0)
        {
        $('#sj-searchresults ul').html('');
        $.each(d,function(k,v){
        $('#sj-searchresults ul').append('<li><a href="http://localhost/samajic/index.php/read/'+v.review_id+'" onclick="getVal(this)">'+v.review_title+'</a></li>');
        });    
        }
        else
        {
        $('#sj-searchresults ul').html('');
        $('#sj-searchresults ul').append('<div>No results found</div>');           
        }    
        });
        $('#sj-searchresults').show();           
        }
        else
        {
        $('#sj-searchresults').hide();    
        }
    });
          
  $('body').click(function(){$('#sj-searchresults').hide()});    
    //End of searchbar      

  function getVal(x)
  {
    var cur=x.innerHTML;
    document.getElementById('searchbar').value=cur;
    document.getElementById('sj-searchresults').style.display='none';
  }


text_truncate = function(str, length, ending) {
    if (length == null) 
    {
      length = 100;
    }
    if (ending == null) 
    {
      ending = '...';
    }
    if (str.length > length) 
    {
      return str.substring(0, length - ending.length) + ending;
    }
    else 
    {
      return str;
    }
  };


$('.sj-prof-change').click(()=>{
$('#profile_edit').modal('open');
var status=$('.sj-prof-status').text();    
var about=$('.sj-prof-about').text();  
$('#prof-status').val(status);
$('#prof-about').val(about);
});




/*Password Strength*/

function passwordChanged() 
{
var strength = document.getElementById('strength');
var strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
var mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
var enoughRegex = new RegExp("(?=.{6,}).*", "g");
var pwd = document.getElementById("password");
if (pwd.value.length==0) {
strength.innerHTML = 'Type Password';
} else if (false == enoughRegex.test(pwd.value)) {
strength.innerHTML = 'More Characters';
$('#password').val('');
$('#password').focus();
} else if (strongRegex.test(pwd.value)) {
strength.innerHTML = '<span style="color:green">Strong!</span>';
} else if (mediumRegex.test(pwd.value)) {
strength.innerHTML = '<span style="color:orange">Medium!</span>';
} else {
strength.innerHTML = '<span style="color:red">Weak!</span>';
$('#password').val('');
$('#password').focus();
}
    
}

/*Password Strength*/ 