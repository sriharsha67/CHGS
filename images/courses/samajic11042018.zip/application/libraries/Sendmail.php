<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sendmail
{
    public function send($to,$subject,$message,$from)
    {
$CI =& get_instance();

$CI->load->helper('url');
$CI->load->library('session');
$CI->config->item('base_url');
$config = Array(
    'protocol' => 'smtp',
    'smtp_host' => 'smtp.manvidesigns.com',
    'smtp_port' => 465,
    'smtp_user' => 'donotreply@samajic.in',
    'smtp_pass' => 'Ram@1234',
    'mailtype'  => 'html', 
    'charset'   => 'iso-8859-1'
);
$CI->load->library('email', $config);
$CI->email->set_newline("\r\n");

$CI->email->from($from, 'Auto-Mailer');
$CI->email->to($to);

$CI->email->subject($subject);
$CI->email->message('Testing the email class.');

$result = $CI->email->send();
return $result;        
    }
    
}
?>