<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <title>Samajic || Page not found</title>

        <link href="<?=base_url()?>assets/css/404.css" rel="stylesheet"/>
        <link href="<?=base_url()?>assets/css/404fonts.css" rel="stylesheet"/>
    
</head>
<body class="notfound" data-gr-c-s-loaded="true">
        <div class="wrapper">
            <div class="big">OOPS! YOU DON'T WANT TO BE HERE</div>
            <div>It looks like it's time to abort mission and go <a href="<?=base_url()?>">Home</a>.</div>
        </div>
</body>
</html>