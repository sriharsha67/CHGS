<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>Samajic</title>
      <style type="text/css">
		  
		 .sj-review-block
		  {
			  display:block;
		  }
		   <style type="text/css">
		.sj-profile-img 
		 {
			 width:175px;
			 height:175px;
			 border:5px solid #fff;
			 border-radius:7px;
			 padding:2px;
		 }
		 .sj-profile-img img
		  {
			  width:75%;
			  text-align: center;
		  }
		  
		  .top-margin
		  {
			margin-top:3%;	  
		  }
		  
		  .sj-profile-desc
		  {
			  border:10px solid #000;
		  }
		  .sj-profile-desc h6 span
		  {
			  font-size:12px;
			  font-weight:600;
		  }
		  .sj-profile-desc-holder
		  {
			  width:175px;
			  text-align: center;
		  }
		  .sj-media,.sj-donate
		  {
			  min-height:200px;
		  }
		  .sj-profile-desc-holder
		  {
			  position:relative;
		  }
		  .sj-profile-desc-holder:before
		  {
				position: absolute;
				top: -19px;
				left: 45%;
				width: 10px;
				height: 10px;
				border: 10px solid #000;
				border-bottom-color: black;
				border-top-color: #fff;
				border-right-color: #FFF;
				border-left-color: #fff;
				content: '';
		  }
		  
		  .profile-loc
		  {
			  
		  }
		  .profile-desg
		  {
			  font-size:11px;
			  padding:3px;
		  }
		  .card-action
		  {
			  height:50px;
		  }
	  </style>
	  </style>
	  
    </head>

    <body>
    
    <nav class="blue darken-1" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="#" class="brand-logo">Samajic</a>
        
      <ul class="right hide-on-med-and-down">
          
        <li>
            <a class="waves-effect modal-trigger" href="#modal1">Login</a>
        </li>
          
        <li>
            <a href="<?=base_url()?>index.php/register">Register</a>
        </li>
          
      </ul>

      <ul id="nav-mobile" class="side-nav">
          
       <h4 class="blue-text center-align">Samajic</h4>
        
        <li>
            
            <a class="waves-effect modal-trigger" href="#modal1">Login</a>
            
        </li>
        
          <li>
              
            <a href="<?=base_url()?>index.php/register">Register</a>
          
          </li>
          
      </ul>
        
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>
   
   
    <div class="row">
    	
<div class="row top-margin">
     	<div class="col s12 m2 sj-profile-holder">
     	
     		<div class="sj-profile-img">
     			<img alt="Profile Image" src="<?=base_url()?>assets/img/default.png"/>
     		</div>
     		
     		<div class="sj-profile-desc-holder center">
 				<div class="sj-profile-desc">
 					<h6 class="profile-title center">Bhargav Ram</h6>
 					<h6 class="profile-loc center"><span class="city">Vizag</span> <span class="state">Andhra Pradesh</span></h6>
 					<h6 class="profile-desg">UI/UX, Web Design</h6>
 				</div>
 			</div>
            
            <div class="sj-basic-info">
            
                <div class="sj-info ">
                    <h6>Blood Group: </h6>                
                    <h6>Place:</h6>                
                </div>
                
            </div>
     	</div>
     	
     	<!--<div class="col s6 m6">
	

 				
 	<form action="" method="post">
 		<div class="input-field col s12 m12">
 		<h5 class="blue-grey-text">Write your review</h5>
		</div>
 	<div class="input-field col s12 m6">
    <select required>
      <option value="" disabled selected>Choose your topic</option>
      <option value="1">Option 1</option>
      <option value="2">Option 2</option>
      <option value="3">Option 3</option>
    </select>
    <label>Select your topic</label>
  	</div>
 		
		<div class="input-field col s12 m12">
          <input required id="sj-review-title" name="review-title" type="text" class="validate">
          <label for="sj-review-title">Title</label>
        </div>
        
        <div class="input-field col s12 m12">
          <textarea required id="sj-review-description" class="materialize-textarea"></textarea>
          <label for="sj-review-description">Write your review</label>
        </div>
        
        
        <div class="file-field col s12 m12 input-field">
      <div class="btn">
        <span>Image</span>
        <input type="file">
      </div>
      <div class="file-path-wrapper">
        <input class="file-path validate" type="text">
            </div>
        </div>
        
        
        <div class="input-field col s12 m6">
        <button type="submit" class="waves-effect waves-light btn"><i class="material-icons left">send</i>Share</a>
			</div>
 				</form>
 				
 						    		
     	</div>-->
    
    <div class="col s6 m6">
    
        <div class="sj-post-wrapper">
        
            <div class="sj-post-select">
                <label>Choose category</label>
                <select name="category">
                <option disabled>Choose your category</option>
                <option value="Mobile">Mobile</option>
                <option value="Mobile">Mobile</option>
                <option value="Mobile">Mobile</option>
                </select>
            </div> 
            <div class="sj-post-input">
                <label>Title</label>
                <input type="text" name="title"/>
            </div>
            
            <div class="sj-post-input input-field">
            <label>Write your review</label>
            <textarea placeholder="Min. 50 characters are required"></textarea>
            </div>
            
            <div class="col s12 m6">
            <div class="sj-post-input input-field">
            <input type="file" name="review-image"/>
            </div>
            </div>
            <div class="col s12 m6">
            <button type="submit" class="waves-effect waves-light btn"><i class="material-icons right">send</i>Post</button>    
            </div>
                
        </div>
    
    </div>
    
        		 <div class="col s6 m4">
    		 	<img src="https://s3.envato.com/files/77714464/580x400.jpg" width="100%"/>
    		 </div>   
    
    
     </div>
 
<hr>

</div>
        
            
     <div class="container">
         
         <div id="content" class="row">
        
<br>
<br>
        

        
      </div>
     
     <div class="row">
     
<div class="col s12">

		 </div>
		 
		 <div class="col s6">
		 
		 </div>
    	 <div class="clearfix"></div>
     </div>
     </div>
        
  
        
        <!-- Modal Structure -->
  <div id="modal1" class="modal">
    <div class="modal-content">
        
        <div class="container">
   <h4 class="deep-orange-text text-darken-2 center">Login Here!</h4>
    <form action="<?=base_url()?>index.php/user/userLogin" method="post" class="col s12 m6 offset-m3">
        <h6 class="red-text"><?php if(isset($_GET['err'])){echo $_GET['err'];}?></h6>
<?php
if(isset($_GET['msg']))
{ 
echo '<h6 class="green-text">'.$_GET['msg'].'</h6>' ;
};
?>
      <div class="row">
        <div class="input-field col s12">
          <input id="username" name="username" autocomplete="new-email" type="email" class="validate">
            <label for="username" data-error="wrong" data-success="right">Email</label>
        </div>
        <div class="input-field col s12">
          <input id="password" name="password" autocomplete="new-password" type="password" class="validate">
          <label for="password">Password</label>
        </div>
		</div>
        <div class="row">
            <div class="col s12">
            <a class="blue-text" href="<?=base_url()?>index.php/forgotpwd">Forgot Password?</a>
            </div>
        </div>
        
  <button class="btn blue lighten-1 waves-effect waves-light register-btn" type="submit" name="action">Login
    <i class="material-icons right">keyboard_return</i>
  </button>
    </form>
  </div>
        
    </div>
  </div>
       	<div id="loader" class="active">
		<img src="http://scrollmagic.io/img/example_loading.gif">
		LOADING...
        </div>

        <style>
        @keyframes bounce
        {
        0%
        {
        top:10px;    
        }
        50%
        {
        top:0px;    
        }
        100%
        {
        top:10px;    
        }
        }
        .card-content
        {
        min-height:116px;        
        }
        #loader
        {
        text-align:center;    
        position:relative;
        animation:bounce 1s linear infinite;
        }
        .box1
        {
        width:100px;    
        height:100px;    
        }
        </style>
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/materialize.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/debug.addIndicators.min.js"></script>
      <script type="text/javascript">
   $(document).ready(function()
	{
    $('select').material_select();   
    $('.modal').modal();
    
       
    <?php   
    
    if(isset($_GET['msg']) || isset($_GET['err']))
    {
        echo "$('#modal1').modal('open');";        
    }
               
    ?>
       
	$(".button-collapse").sideNav();
       
    });
		  

    
    // init controller
	var controller = new ScrollMagic.Controller();

	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#loader", triggerHook: "onEnter"})
					.addTo(controller)
					.on("enter", function (e) {
						if (!$("#loader").hasClass("active")) {
							$("#loader").addClass("active");
                            /*
                            if (console)
                            {
								console.log("loading new items");
							}
                            */
							// simulate ajax call to add content using the function below
							setTimeout(addBoxes, 1000, 9);
						}
					});
    
    var reviews=0;
	// pseudo function to add new content. In real life it would be done through an ajax request.
	function addBoxes (amount=0) 
     {
        reviews+=amount;
        $.get('<?=base_url()?>index.php/User/get_reviews/'+reviews+'',(d)=>
        {
        for (i=0; i<d['data'].length; i++) 
        {   
			var box='<a href="#" target="_blank"><div class="col s12 m12"><div class="card"><div class="card-image"><img src="<?=base_url()?>assets/img/sample-1.jpg"><span class="card-title">'+d.data[i].review_title+'</span></div><div class="card-content"><p>'+text_truncate(d.data[i].review_desc)+'</p></div>            <!--<div class="card-action"><a href="#">This is a link</a></div>-->        </div> </div></div></a>';
            $('#content').append(box); 
		}
        $('#loader').html('<h6 class="grey-text">'+d.res+'...</h6>');    
        });

		// "loading" done -> revert to normal state
		scene.update(); // make sure the scene gets the new start position
		$("#loader").removeClass("active");
	}

          
	// add some boxes to start with.
	addBoxes();
      
    text_truncate = function(str, length, ending) {
    if (length == null) 
    {
      length = 100;
    }
    if (ending == null) 
    {
      ending = '...';
    }
    if (str.length > length) 
    {
      return str.substring(0, length - ending.length) + ending;
    }
    else 
    {
      return str;
    }
  };      
  
	  </script>
        
        
    </body>
  </html>
        