<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/materialize.min.css"  media="screen,projection"/>
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/style.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>Samajic</title>
      <style type="text/css">
          
	  </style>
	  
    </head>

    <body>
    
<div class="navbar-fixed">
    <nav class="blue darken-1" role="navigation">
    <div class="nav-wrapper container">
    <a id="logo-container" href="<?=base_url()?>" class="brand-logo">Samajic</a>        
        
        
    <ul class="sj-searchbar left hide-on-med-and-down">
    <li>
       <input type="search" id="searchbar" name="search" autocomplete="off" placeholder="Search"/>
    </li>
    <div id="sj-searchresults">
        <ul>
            
        </ul>
    </div>    
    </ul>    
        
      <ul class="right hide-on-med-and-down">
          
        <li>
          <a href="<?=base_url()?>index.php/User/profile"><img src="<?=base_url()?>assets/img/uploads/<?=$_SESSION['profile_pic']?>" alt="" class="circle responsive-img cir_pic"></a>
        </li>   
          
        <li class="active">
            <a href="<?=base_url()?>">Home</a>
        </li>
          
        <li>
            <li><a href="<?=base_url()?>index.php/logout">Logout</a></li>
        </li>
          
      </ul>

      <ul id="nav-mobile" class="side-nav">
          
       <h4 class="blue-text center-align">Samajic</h4>
        
        <li>
            <a href="<?=base_url()?>">Home</a>
            
            
        </li>
        
          <li>
            <a href="<?=base_url()?>index.php/logout">Logout</a>
          </li>
          
      </ul>
        
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
    </nav>
  </div>
   
   <style>
    /*
    body
    {
    background:rgb(231, 231, 231);    
    }
   .sj-home-grid
    {       
        position:fixed;
        min-height:300px;
        border:1px  solid #ccc;
        width: 250px;
        margin:.5em;
        background:#fff;
    }
       
    .sj-post-grid
    {
        position:relative;
        height:342px;
        margin:.5em;
        background:#fff;
        border-radius:7px;        
    }
       
    .sj-right-grid
    {
        position:fixed;
        height:auto;
    }
       
    .sj-right-grid > div
       {
         width:300px;
        height:300px;
        margin:.5em;
        border-radius:3px;
       }
       
    .sj-grid
    {
    position:relative;
    }
    .sj-home-pic
    {
     text-align:center;
     
    }
    .sj-home-pic img
    {
        text-align:center;
    }
    
    .sj-home-name h6
    {
    font-weight:bold;
    text-align:center;
    }
       
    .sj-home-abt p,.sj-status p
   {
    font-size:14px;   
    }
    .sj-home-abt,.sj-status
    {
    margin:.5em;
    }*/
   </style>
        <div class="container">
             
             <div class="row">
            
            <div class="col s12 m3 sj-grid">
            
                <div class="sj-home-grid z-depth-2">
                    
                   <div class="sj-home-pic">
                   
                       <a href="<?=base_url()?>index.php/profile">
                           <img class="z-depth-2 hoverable responsive-img" src="<?=base_url()?>/assets/img/uploads/<?=$_SESSION['profile_pic']?>"/>
                       </a>
                   </div> 
                   
                    <div class="sj-home-name">
                        
                    <h6><?=$_SESSION['first_name']?></h6>
                        
                    </div>
                    <div class="sj-status">
                    <p>Status</p>
                    <p><?=$_SESSION['profile_status']?></p>
                    </div>
            <div class="sj-home-abt hide-on-med-and-down">
                <p>About me</p>
                <p>
                    <?=$_SESSION['about_me']?>
                </p>
                </div>
                </div>             
                
            </div>
            
            <div class="col s12 m6 sj-grid">
            
<div class="sj-post-grid z-depth-3 hoverable">
    <form enctype="multipart/form-data" action="<?=base_url()?>index.php/User/post" method="post">
 		<div class="input-field col s12 m12">
 		<h5 class="blue-grey-text">Write your review</h5>
		</div>
 	<div class="input-field col s12 m6">
    <select required name="rev-category">
        <option value="" disabled selected>Choose your topic</option>
            <option value="Movies">Movies</option>
<!--
<option value="Telugu">Telugu</option>
<option value="Hindi">Hindi</option>
<option value="English">English</option>
<option value="Tamil">Tamil</option>
<option value="Malayalam">Malayalam</option>
-->
<option value="Electronics">Electronics</option>
<option value="Mobiles">Mobiles</option>
<option value="Mobile Accessories">Mobile Accessories</option>
<option value="Laptops">Laptops</option>
<option value="Desktop PC">Desktop PC</option>
<option value="Tablets">Tablets</option>
<option value="Cameras">Cameras</option>
<option value="TVs">TVs</option>
<option value="Home Appliances">Home Appliances</option>
<option value="Fashion">Fashion</option>
<option value="Men">Men</option>
<option value="Women">Women</option>
<option value="Kids">Kids</option>
<option value="Home & Furniture">Home & Furniture</option>
<option value="Books">Books</option>
<option value="Sports">Sports</option>
<option value="Services">Services</option>
<option value="Others">Others</option>
    </select>
    <label>Select your topic</label>
  	</div>
 		
		<div class="input-field col s12 m6">
          <input required id="sj-review-title" name="rev-title" type="text" class="validate">
          <label for="sj-review-title">Write yout title</label>
        </div>
        
        <div class="input-field col s12 m12">
          <textarea name="rev-desc" required id="sj-review-description" class="materialize-textarea"></textarea>
          <label for="sj-review-description">Write your review</label>
        </div>
        
        
        <div class="file-field col s12 m6 input-field">
      <div class="btn blue darken-1">
        <span><i class="material-icons left">image</i>Image</span>
        <input type="file" accept="image/*" name="rev-image"  required/>
      </div>
        </div>
        
        
        <div class="input-field file-field col s12 m6 ">
            <button type="submit" class="blue darken-1 waves-effect waves-light btn"><i class="material-icons left">send</i>Share</a>
		</div>
</form>
                
                 
</div>            
                
 	    
   
       <div id="content" class="row">
            
            
       </div>
       
 
                
            </div>
            
            
            <div class="col s12 m3 sj-grid">
            
                <div class="sj-right-grid">
                <div class="z-depth-1">
                <img src="<?=base_url()?>assets/img/adblock.jpg"/>
                </div>
                <div class="z-depth-1">
                <img src="<?=base_url()?>assets/img/adblock.jpg"/>
                </div>
                </div>
                
            </div>
        
        </div>
        </div>    
        
       
       	<div id="loader" class="active">
		<img src="<?=base_url()?>assets/img/loading.gif">
		LOADING...
        </div>

      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="<?=base_url()?>assets/js/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/materialize.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/debug.addIndicators.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/main.js"></script>
      <script type="text/javascript">
          
    // init controller
	var controller = new ScrollMagic.Controller();

	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#loader", triggerHook: "onEnter"})
					.addTo(controller)
					.on("enter", function (e) {
						if (!$("#loader").hasClass("active")) {
							$("#loader").addClass("active");
                            /*
                            if (console)
                            {
								console.log("loading new items");
							}
                            */
							// simulate ajax call to add content using the function below
							setTimeout(addBoxes, 1000, 9);
						}
					});
	
	function addBoxes (amount=0) 
     {
        reviews+=amount;
        $.get('<?=base_url()?>index.php/reviews/'+reviews+'',(d)=>
        {
        for (i=0; i<d['data'].length; i++) 
        {   
			var box='<a href="#" target="_blank"><div class="col s12 m12"><div class="card hoverable"><div class="card-image"><img class="responsive-img" src="<?=base_url()?>assets/img/uploads/'+d.data[i].review_image+'"><span class="card-title">'+d.data[i].review_title+'</span></div><div class="card-content"><p>'+text_truncate(d.data[i].review_desc)+'</p></div>            <!--<div class="card-action"><a href="#">This is a link</a></div>-->        </div> </div></div></a>';
            $('#content').append(box); 
		}
        $('#loader').html('<h6 class="grey-text">'+d.res+'...</h6>');    
        });

		// "loading" done -> revert to normal state
		scene.update(); // make sure the scene gets the new start position
		$("#loader").removeClass("active");
	}

          
	// add some boxes to start with.
	addBoxes();
      
  
	  </script>
        
        
    </body>
  </html>
        