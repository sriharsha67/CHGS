<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/materialize.min.css"  media="screen,projection"/>
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/style.css"  media="screen,projection"/>
      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>Samajic</title>
      <style type="text/css">
		  
		 .sj-review-block
		  {
			  display:block;
		  }
		  
	  </style>
	  
    </head>

    <body>
    
      <div class="navbar-fixed">
    <nav class="blue darken-1" role="navigation">
    <div class="nav-wrapper container">
    <a id="logo-container" href="#" class="brand-logo">Samajic</a>        
        
        
    <ul class="sj-searchbar left hide-on-med-and-down">
    <li>
       <input type="search" id="searchbar" name="search" autocomplete="off" placeholder="Search"/>
    </li>
    <div id="sj-searchresults">
        <ul>
            
        </ul>
    </div>    
    </ul>    
        
      <ul class="right hide-on-med-and-down">
          
        <li>
            <a class="waves-effect modal-trigger" href="#modal1">Login</a>
        </li>
          
        <li>
            <a href="<?=base_url()?>index.php/register">Register</a>
        </li>
          
      </ul>

      <ul id="nav-mobile" class="side-nav">
          
       <h4 class="blue-text center-align">Samajic</h4>
        
        <li>
            
            <a class="waves-effect modal-trigger" href="#modal1">Login</a>
            
        </li>
        
          <li>
              
            <a href="<?=base_url()?>index.php/register">Register</a>
          
          </li>
          
      </ul>
        
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
    </nav>
    </div>
   
   
    
     <div class="container">
     
     <div class="row">
     
<div class="col s12 m6">
<div class="row">
   <h4 class="deep-orange-text text-darken-2">Registration Form</h4>
    <form action="<?=base_url()?>index.php/user/userRegister" method="post" class="col s12">
        <h6 class="red-text"><?php if(isset($_GET['err'])){echo $_GET['err'];}?></h6>
      <div class="row">

        <div class="input-field col s12 m6">
          <input id="first_name" name="first_name" required type="text" class="validate">
          <label for="first_name">First Name</label>
        </div>
        <div class="input-field col s12 m6">
          <input id="last_name" name="last_name" required type="text" class="validate">
          <label for="last_name">Last Name</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input id="mobile" name="mobile" type="text" required maxlength="10" class="validate">
          <label for="mobile">Mobile Number</label>
        </div>
      </div>
        
        <div class="row">
          <div class="input-field col s12">
            <select>
              <option value="" disabled selected>Choose your Blood group</option>
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>
        </div>

      <div class="row">
        <div class="input-field col s12">
          <input id="email" name="email" type="email" required class="validate">
           <label for="email" data-error="wrong" data-success="right">Email</label>
          <label for="email">Email</label>
        </div>
      </div>
        
        
    <div class="row">
            <div class="input-field col s12 m12">
          <input id="dob" name="dob" required type="date" placeholder="YYYY-MM-DD"/> 
          <label for="dob">Date of Birth</label>
        </div>

      </div>
    
      <div class="row">
        <div class="pwd_tooltip">
            <ul>
            <li>Password must contain:</li>
            <li>Atleast 6 characters</li>
            <li>A capital letter</li>
            <li>A special character</li>
            <li>A number</li>
          </ul>
        </div>
        <div class="input-field col s12 pwd-field">
          <input id="password" name="password" type="password" required class="validate" onblur="return passwordChanged()">
          <label for="password">Password</label>     
        </div>
          <div class="col s6">
          <span id="strength"></span> 
                    </div>
      </div> 
        
      <div class="row">
        <div class="input-field col s12">
          <input id="confirm-password" type="password" required class="validate">
          <label for="confirm-password">Confirm Password</label>
        </div>
      </div>
      <div class="row">
		<p>
      <input type="checkbox" id="t&c" onclick="check()"/>
      <label for="t&c">I agree for <a href="#">Terms & Conditions</a></label>
    	</p>
      </div>

  <button class="btn blue lighten-1 waves-effect waves-light disabled register-btn" type="submit">Register
    <i class="material-icons right">keyboard_return</i>
  </button>
    </form>
  </div>
		 </div>
		 
		 <div class="col s6">
		 
		 </div>
    	 <div class="clearfix"></div>
     </div>
     </div>
        
<!--Modal1-->
        
<div id="modal1" class="modal">
    <div class="modal-content">
        
        <div class="container">
   <h4 class="deep-orange-text text-darken-2 center">Login Here!</h4>
    <form action="<?=base_url()?>index.php/user/userLogin" method="post" class="col s12 m6 offset-m3">
        <h6 class="red-text"><?php if(isset($_GET['err'])){echo $_GET['err'];}?></h6>
<?php
if(isset($_GET['msg']))
{ 
echo '<h6 class="green-text">'.$_GET['msg'].'</h6>' ;
};
?>
      <div class="row">
        <div class="input-field col s12">
          <input id="username" name="username" autocomplete="new-email" type="email" class="validate">
            <label for="username" data-error="wrong" data-success="right">Email</label>
        </div>
        <div class="input-field col s12">
          <input id="pwd" name="password" autocomplete="new-password" type="password" class="validate">
          <label for="pwd">Password</label>
        </div>
		</div>
        <div class="row">
            <div class="col s12">
            <a class="blue-text" href="<?=base_url()?>index.php/forgotpwd">Forgot Password?</a>
            </div>
        </div>
        
  <button class="btn blue lighten-1 waves-effect waves-light register-btn" type="submit" name="action">Login
    <i class="material-icons right">keyboard_return</i>
  </button>
    </form>
  </div>
        
    </div>
  </div>
        
<!--Modal1-->        
        
        
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/materialize.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/main.js"></script>
      <script type="text/javascript">
$(document).ready(function(){
    $("#mobile").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl/cmd+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: Ctrl/cmd+C
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: Ctrl/cmd+X
            (e.keyCode == 88 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
		  
	$('#confirm-password').focusout(function()
	{
		var pwd=$('#password');
		var cnf_pwd=$('#confirm-password');
		if(pwd.val()!=cnf_pwd.val())
		{	
			cnf_pwd.val('');
			pwd.val('').focus();	
		}
	});	 
    
});		  		  
		
		  
function check() {
  // Get the checkbox
  var checkBox = document.getElementById("t&c");

  // If the checkbox is checked, display the output text
  if (checkBox.checked == true){
    $('.register-btn').removeClass('disabled');	
  } else {
    $('.register-btn').addClass('disabled');	
  }
}

     $('#password').focusin(function(){
        $('.pwd_tooltip').toggle(); 
     });
          
     $('#password').focusout(function(){
        $('.pwd_tooltip').toggle(); 
     });
          
    
	  </script>
    </body>
  </html>
        