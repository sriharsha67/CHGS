<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>Samajic</title>
      <style type="text/css">
		  
		 .sj-review-block
		  {
			  display:block;
		  }
		  
	  </style>
	  
    </head>

    <body>
    
    <nav class="blue darken-1" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="#" class="brand-logo">Samajic</a>
      <ul class="right hide-on-med-and-down">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="<?=base_url()?>index.php/register">Register</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
       <h4 class="blue-text center-align">Samajic</h4>
        <li class="active"><a href="#">Home</a></li>
        <li><a href="<?=base_url()?>index.php/register">Register</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>
   
   
    
     <div class="container">
     
     <div class="row">
     
<div class="col s12">
<div class="row">
   <h5 class="deep-orange-text text-darken-2 center">Please reset your password here!</h5>
    <form action="<?=base_url()?>index.php/forgotpwd/changepwd" method="post" class="col s12 m6 offset-m3">
        <h6 class="red-text"><?php if(isset($_GET['err'])){echo $_GET['err'];}?></h6>
<?php
if(isset($_GET['msg']))
{ 
echo '<h6 class="green-text">'.$_GET['msg'].'</h6>' ;
};
?>
      <div class="row">
        <div class="input-field col s12">
          <input id="password" name="password" min="6" type="password" required class="validate">
          <label for="password">New Password</label>
        </div>
      </div> 
      <div class="row">
        <div class="input-field col s12">
          <input id="confirm-password" min="6" type="password" required class="validate">
          <label for="confirm-password">Confirm Password</label>
        </div>
      </div>
        <input type="hidden" name="key" value="<?=$hash?>"/>

  <button class="btn blue lighten-1 waves-effect waves-light register-btn" type="submit" >Reset
    <i class="material-icons right">keyboard_return</i>
  </button>
    </form>
  </div>
		 </div>
		 
		 <div class="col s6">
		 
		 </div>
    	 <div class="clearfix"></div>
     </div>
     </div>
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/materialize.min.js"></script>
      <script type="text/javascript">
   $(document).ready(function()
	{
	$(".button-collapse").sideNav();
       
    $('#confirm-password').focusout(function()
	{
		var pwd=$('#password');
		var cnf_pwd=$('#confirm-password');
		if(pwd.val()!=cnf_pwd.val())
		{	
			cnf_pwd.val('');
			pwd.val('').focus();	
		}
	});	   
       
});
		  

  
	  </script>
    </body>
  </html>
        