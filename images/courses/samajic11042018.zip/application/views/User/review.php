<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/materialize.min.css"  media="screen,projection"/>
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/style.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>Samajic</title>
      <style type="text/css">
          
	  </style>
	  
    </head>

    <body>
    
<div class="navbar-fixed">
    <nav class="blue darken-1" role="navigation">
    <div class="nav-wrapper container">
    <a id="logo-container" href="<?=base_url()?>" class="brand-logo">Samajic</a>        
        
    <ul class="sj-searchbar left hide-on-med-and-down">
    <li>
       <input type="search" id="searchbar" name="search" autocomplete="off" placeholder="Search"/>
    </li>
    <div id="sj-searchresults">
        <ul>
            
        </ul>
    </div>    
    </ul>    
        
      <ul class="right hide-on-med-and-down">
          
        <?php
        if(isset($_SESSION['loggedin']))
        {
          ?>
          <li class="valign-wrapper">
         <a href="<?=base_url()?>index.php/User/profile">
            <img src="<?=base_url()?>assets/img/uploads/<?=$_SESSION['profile_pic']?>" alt="" class="circle responsive-img cir_pic">
         </a>
        </li>
        <li>
            <a href="<?=base_url()?>">Home</a>
        </li>
          
        <li>
            <li><a href="<?=base_url()?>index.php/logout">Logout</a></li>
        </li>  
          
          <?php
        }
        else
        {
            
        ?>
          
        <li>
            <a class="waves-effect modal-trigger" href="#modal1">Login</a>
        </li>
        
        <li>
            <li><a href="<?=base_url()?>index.php/register">Register</a></li>
        </li>
        <?php
        }
        ?>
      </ul>

      <ul id="nav-mobile" class="side-nav">
          
       <h4 class="blue-text center-align">Samajic</h4>
        
          <li><ul class="sj-searchbar left show-on-med-and-down">
    <li>
       <input type="search" id="searchbar" name="search" autocomplete="off" placeholder="Search"/>
    </li>
    <div id="sj-searchresults">
        <ul>
            
        </ul>
    </div>    
    </ul>    
</li>
          
        <li>
            <a href="<?=base_url()?>">Home</a>
            
            
        </li>
        
          <li>
            <a href="<?=base_url()?>index.php/logout">Logout</a>
          </li>
          
      </ul>
        
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
    </nav>
  </div>

        <div class="container">
             
        <div class="row">
            <div class="col s12 m9 sj-grid">
                <div class="card">
        <div class="card-image">
          <img class="sj-rev-img" src="<?=base_url()?>assets/img/uploads/<?=$review->review_image?>">
          <!--<span class="card-title"></span>-->
        </div>
        <div class="card-content">
            <h5><?=$review->review_title?></h5>
            <p><?=$review->review_desc?></p>
            </div>
                </div>
            </div>
            
            
            
            <div class="col s12 m3 sj-grid">
            
                <div class="sj-right-grid">
                <div class="z-depth-1">
                <img src="<?=base_url()?>assets/img/adblock.jpg"/>
                </div>
                <div class="z-depth-1">
                <img src="<?=base_url()?>assets/img/adblock.jpg"/>
                </div>
                </div>
                
            </div>
        
        </div>
        </div>    
        

<div id="modal1" class="modal">
    <div class="modal-content">
        
        <div class="container">
   <h4 class="deep-orange-text text-darken-2 center">Login Here!</h4>
    <form action="<?=base_url()?>index.php/user/userLogin" method="post" class="col s12 m6 offset-m3">
        <h6 class="red-text"><?php if(isset($_GET['err'])){echo $_GET['err'];}?></h6>
<?php
if(isset($_GET['msg']))
{ 
echo '<h6 class="green-text">'.$_GET['msg'].'</h6>';
}
?>
      <div class="row">
          
        <div class="input-field col s12">
          <input id="username" name="username" autocomplete="new-email" type="email" class="validate">
          <label for="username" data-error="wrong" data-success="right">Email</label>
        </div>
          

          
        <div class="input-field col s12">
          <input id="password" name="password" autocomplete="new-password" type="password" class="validate">
          <label for="password">Password</label>
        </div>
          
      </div>
        <div class="row">
            <div class="col s12">
            <a class="blue-text" href="<?=base_url()?>index.php/forgotpwd">Forgot Password?</a>
            </div>
        </div>
        
  <button class="btn blue lighten-1 waves-effect waves-light register-btn" type="submit" name="action">Login
    <i class="material-icons right">keyboard_return</i>
  </button>
    </form>
  </div>
        
    </div>
  </div>
        
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="<?=base_url()?>assets/js/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/materialize.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/main.js"></script>        

        
    </body>
  </html>
        