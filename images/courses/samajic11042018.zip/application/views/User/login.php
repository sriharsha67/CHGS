<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/materialize.min.css"  media="screen,projection"/>
      <link type="text/css" rel="stylesheet" href="<?=base_url()?>assets/css/style.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>Samajic</title>
      <style type="text/css">
		  /*
		 .sj-review-block
		  {
			  display:block;
		  }
		  
          .sj-searchbar
          {
            position:relative;
            left:30%;
            width:300px;
          }
          
          .sj-searchbar li input 
            {
            width: 300px !important;
            background: white !important;
            border-radius: 7px !important;
            padding-left: 25px !important;
            color: black;
           }
          .sj-searchbar li input::placeholder
          {
              color:black;
          }
          */
	  </style>
	  
    </head>
    <body> 
        
    <div class="navbar-fixed">
    <nav class="blue darken-1" role="navigation">
    <div class="nav-wrapper container">
    <a id="logo-container" href="#" class="brand-logo">Samajic</a>        
        
        
    <ul class="sj-searchbar left hide-on-med-and-down">
    <li>
       <input type="search" id="searchbar" name="search" autocomplete="off" placeholder="Search"/>
    </li>
    <div id="sj-searchresults">
        <ul>
            
        </ul>
    </div>    
    </ul>    
        
      <ul class="right hide-on-med-and-down">
          
        <li>
            <a class="waves-effect modal-trigger" href="#modal1">Login</a>
        </li>
          
        <li>
            <a href="<?=base_url()?>index.php/register">Register</a>
        </li>
          
      </ul>

      <ul id="nav-mobile" class="side-nav">
          
       <h4 class="blue-text center-align">Samajic</h4>
        
        <li>
            
            <a class="waves-effect modal-trigger" href="#modal1">Login</a>
            
        </li>
        
          <li>
              
            <a href="<?=base_url()?>index.php/register">Register</a>
          
          </li>
          
      </ul>
        
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
    </nav>
    </div>
   
   
    
     <div class="container">
         
         <div id="content" class="row">
        
<br>
<br>
        

        
      </div>
     
     <div class="row">
     
<div class="col s12">

		 </div>
		 
		 <div class="col s6">
		 
		 </div>
    	 <div class="clearfix"></div>
     </div>
     </div>
        
  
        
        <!-- Modal Structure -->
  <div id="modal1" class="modal">
    <div class="modal-content">
        
        <div class="container">
   <h4 class="deep-orange-text text-darken-2 center">Login Here!</h4>
    <form action="<?=base_url()?>index.php/user/userLogin" method="post" class="col s12 m6 offset-m3">
        <h6 class="red-text"><?php if(isset($_GET['err'])){echo $_GET['err'];}?></h6>
<?php
if(isset($_GET['msg']))
{ 
echo '<h6 class="green-text">'.$_GET['msg'].'</h6>' ;
};
?>
      <div class="row">
        <div class="input-field col s12">
          <input id="username" name="username" autocomplete="new-email" type="email" class="validate">
            <label for="username" data-error="wrong" data-success="right">Email</label>
        </div>
        <div class="input-field col s12">
          <input id="password" name="password" autocomplete="new-password" type="password" class="validate">
          <label for="password">Password</label>
        </div>
		</div>
        <div class="row">
            <div class="col s12">
            <a class="blue-text" href="<?=base_url()?>index.php/forgotpwd">Forgot Password?</a>
            </div>
        </div>
        
  <button class="btn blue lighten-1 waves-effect waves-light register-btn" type="submit" name="action">Login
    <i class="material-icons right">keyboard_return</i>
  </button>
    </form>
  </div>
        
    </div>
  </div>
       	<div id="loader" class="active">
		<img src="<?=base_url()?>assets/img/loading.gif">
		LOADING...
        </div>

        <style>
        /*@keyframes bounce
        {
        0%
        {
        top:10px;    
        }
        50%
        {
        top:0px;    
        }
        100%
        {
        top:10px;    
        }
        }
        .card-content
        {
        min-height:116px;        
        }
        #loader
        {
        text-align:center;    
        position:relative;
        animation:bounce 1s linear infinite;
        }
        .box1
        {
        width:100px;    
        height:100px;    
        }
        #sj-searchresults > ul > li
        {
        clear:both;
        list-style: none;
        }
            
        #sj-searchresults > ul > li
        {
        color:black;
        padding:8px;
        margin:5px;
        height:35px;
        line-height:15px;
        width:96.5%;
        }
        
        #sj-searchresults > ul > div
        {
            color:black;    
        }
            
        #sj-searchresults >  ul > li:hover
        {
        cursor:pointer;
        background:#ccc;
        transition:.25s linear all;
        -webkit-transition:.25s linear all;
        -moz-transition:.25s linear all;
        -ms-transition:.25s linear all;
        -o-transition:.25s linear all;
        }
            
        #sj-searchresults
        {
        position: absolute;
        top: 41px;  
        left: 14px;
        width: 100%;
        border-radius: 7px;
        background: white;
        z-index: 99;
        display:none;
        transition:.25s all linear;
        -webkit-transition:.25s all linear;
        -moz-transition:.25s all linear;
        -ms-transition:.25s all linear;
        }*/
              
        </style>
      <!--Import jQuery before materialize.js-->
      <script type="text/javascript" src="<?=base_url()?>assets/js/jquery-3.2.1.min.js"></script>
      <script type="text/javascript" src="<?=base_url()?>assets/js/materialize.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/debug.addIndicators.min.js"></script>
        <script type="text/javascript" src="<?=base_url()?>assets/js/main.js"></script>
<script type="text/javascript">

   $(document).ready(function()
	{
       
    <?php   
    
    if(isset($_GET['msg']) || isset($_GET['err']))
    {
        echo "$('#modal1').modal('open');";        
    }
               
    ?>
       
    });
		
    // init controller
	var controller = new ScrollMagic.Controller();

	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#loader", triggerHook: "onEnter"})
					.addTo(controller)
					.on("enter", function (e) {
						if (!$("#loader").hasClass("active")) {
							$("#loader").addClass("active");
                            /*
                            if (console)
                            {
								console.log("loading new items");
							}
                            */
							// simulate ajax call to add content using the function below
							setTimeout(addBoxes, 1000, 9);
						}
					});
    
    
	function addBoxes (amount=0) 
     {
        reviews+=amount;
        $.get('<?=base_url()?>index.php/reviews/'+reviews+'',(d)=>
        {
        for (i=0; i<d['data'].length; i++) 
        {   
			var box='<a href="<?=base_url()?>index.php/read/'+d.data[i].review_id+'" target="_blank"><div class="col s12 m4"><div class="card"><div class="card-image"><img src="<?=base_url()?>assets/img/sample-1.jpg"><span class="card-title">'+d.data[i].review_title+'</span></div><div class="card-content"><p>'+text_truncate(d.data[i].review_desc)+'</p></div>            <!--<div class="card-action"><a href="#">This is a link</a></div>-->        </div> </div></div></a>';
            $('#content').append(box); 
		}
        $('#loader').html('<h6 class="grey-text">'+d.res+'...</h6>');    
        });

		// "loading" done -> revert to normal state
		scene.update(); // make sure the scene gets the new start position
		$("#loader").removeClass("active");
	}

          
	// add some boxes to start with.
	addBoxes();
      
          
  

          
</script>
        
        
    </body>
  </html>
