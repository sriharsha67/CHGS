<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/*
     *
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    
	public function index()
	{
        
        if(isset($_SESSION['logged_in']))
        {
        //echo 'You are logged in with email '.$this->session->email.'<br><a href="http://localhost/samajic/index.php/User/logout">Logout</a>';
        $this->home();
        }
        else
        {
            $this->load->view('User/login');
        }
	}
    
    public function register()
	{
        
            $this->load->view('User/register');
	}
    
    
    public function profile()
	{
        if($this->session->userdata('email'))
        {
            $this->load->view('header');
            $this->load->view('User/profile');
        }
        else
        {
            redirect('User');
        }
        
    }
    

    public function read_review($slug=null)
	{
        $review=$this->db->get_where('samajic_reviews',array('review_id'=>$slug))->row();
        $data=array('review'=>$review);
/*        if($slug==null)
        {
            show_404();
        }
        else
        {
        //$this->db->get_where('samajic_reviews',array());    
        $this->load->view('User/review',$data);    
        }*/
        $this->load->view('User/review',$data);    
    }
    


    
    
    public function home()
    {
        if($this->session->userdata('email'))
        {
            $this->load->view('header');
            $this->load->view('User/home');
        }
        else
        {
            redirect('User');
        }
    }
    
    public function verify($id)
	{
        $this->_verifyEmail($id);
	}

    public function userLogin()
    {

       $username = $this->input->post('username');
       $password = $this->input->post('password');
       $query=$this->db->get_where('samajic_users',array('email'=>$username,'password'=>md5($password),'status'=>1));
        if($query->num_rows()>0)
        {
            $result=$query->row();
            $data = array(
            'user_id'   => $result->id,    
            'email'     => $username,
            'first_name'=> $result->first_name,    
            'profile_pic'=> $result->profile_pic,    
            'profile_status'=> $result->profile_status,    
            'about_me'=> $result->about_me,    
            'logged_in' => TRUE
            );
            $this->session->set_userdata($data);
            redirect('User/home');
            //echo 'You are logged in '.$result->first_name.'<br><a href="logout">Logout</a>';
        }
        else
        {
            redirect('User/?err=Invalid credentials!!!');
        }

    }
    
    
    public function userRegister()
    {
    
        $firstname=$this->input->post('first_name');
        $lastname=$this->input->post('last_name');
        $email = $this->input->post('email');
	    $password = $this->input->post('password');
	    $mobile = $this->input->post('mobile');
        $mail_key=md5('$email');
        $data=array('id'=>'',
                    'first_name'=>$firstname,
                    'last_name'=>$lastname,
                    'email'=>$email,
                    'password'=>md5($password),
                    'mobile_no'=>$mobile,
                    'status'=>0,
                    'mail_key'=>$mail_key
                   );

        $query=$this->db->insert('samajic_users',$data);        
        if($this->db->affected_rows()>0)
        {
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= 'From: Auto-mailer<donotreply@samajic.in>'."\r\n";
            $message = "
<html>
<head>
<title>Samajic Mail Verification</title>
</head>
<body>
<p>Hi ".$firstname."</p>
<p>Welcome to Samajic</p>
<p>Please comfirm your mail id by clickin the below link:</p>
<p style='font-size:18px;color:blue;'><a target='_blank' href='http://www.samajic.in/index.php/user/verify/".$mail_key."'>Click Here</a></p>
</body>
</html>
";
            mail($email,'Samajic - Verify Email',$message,$headers);
            redirect(base_url().'?msg=Registered Successfully!!<br>Please check your inbox for verification email from us.');
        }
        else
        {
            redirect(base_url().'index.php/register?err=You are already registered with us!!!');
        }
    }
    
    
    private function _verifyEmail($mail_key)
    {
      $data=array('status'=>1);
      $check = $this->db->get_where('samajic_users',array('mail_key'=>$mail_key,'status'=>1));
      if($check->num_rows()>0)
      {
          echo 'You are already verified';
      }
        else
        {
      $query=$this->db->update('samajic_users',$data,array('mail_key'=>$mail_key));    
      if($this->db->affected_rows()>0)
      {
          echo "Your email has been verified successfully.";
      }
      else
      {
          echo 'The key doesn\'t match, please check again.';
      }
        }
    }
    

    public function get_reviews($offset=0)
    {       
        
        $this->db->from('samajic_reviews');
        $this->db->order_by("created_on", "desc");
        $this->db->limit(9,$offset);
        $query = $this->db->get();
        $res=$query->result_object();
        if(count($res)>=9)
        {
        $this->output->set_content_type('application/json')->set_output(json_encode(array('data'=>$res,'res'=>'Loading')));      
        }
        else
        {
        $this->output->set_content_type('application/json')->set_output(json_encode(array('data'=>$res,'res'=>'End of the Feed')));    
        }
        
    }
    
    
    
    public function get_user_reviews($offset=0,$id)
    {       
         if($this->checkLogin())
         {
        $this->db->from('samajic_reviews');
        $this->db->where('user_id', $id);
        $this->db->order_by("created_on", "desc");
        $this->db->limit(9,$offset);
        $query = $this->db->get();
        $res=$query->result_object();
        if(count($res)>=9)
        {
        $this->output->set_content_type('application/json')->set_output(json_encode(array('data'=>$res,'res'=>'Loading')));      
        }
        else
        {
        $this->output->set_content_type('application/json')->set_output(json_encode(array('data'=>$res,'res'=>'End of the Feed')));    
        }   
         }
        else
        {
        $this->output->set_content_type('application/json')->set_output(json_encode(array('err'=>'Authentication error'))); 
        }
        
        
    }

    
    public function checkLogin()
    {
        if(isset($_SESSION['logged_in']))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public function search($keyword='')
    {
        $this->db->select('review_id,review_title');
        $this->db->like('review_title', $keyword);
        $this->db->limit(5);
        $res = $this->db->get('samajic_reviews');
        $res = $res->result_array();
        $this->returnJson($res);
    }
    
    
    
    public function post()
    {
        $upld=$this->uploadImage();
        $rand=rand(10000,99999999);    
        $data=array(
                    'review_id'=>time(),
                    'review_title'=>$this->input->post('rev-title'),
                    'review_category'=>$this->input->post('rev-category'),
                    'review_desc'=>$this->input->post('rev-desc'),
                    'review_image'=>$upld,
                    'user_id'=>$_SESSION['user_id']
                    );
        $query=$this->db->insert('samajic_reviews',$data);
        if($this->db->affected_rows())
        {
        
            redirect('User');
        }
        //echo $this->db->affected_rows();
    }
    
    public function uploadImage()
    {
        $rand=rand(111111,999999);    
        $configUpload['upload_path']    = './assets/img/uploads/';       
        $configUpload['allowed_types']  = 'gif|jpg|png|bmp|jpeg';       
        $configUpload['file_name']  = md5($rand.$_SESSION['first_name']);
        $configUpload['file_ext']       = '.jpg';                         
        $configUpload['max_size']       = '2048';                         
        $configUpload['max_width']      = '0';                          
        $configUpload['max_height']     = '0';                         
        $this->load->library('upload', $configUpload);       
        if(!$this->upload->do_upload('rev-image'))
        {
            $uploadedDetails    = $this->upload->display_errors();
        }
        else
        {
            $uploadedDetails    = $this->upload->data('file_name');
            //echo $uploadedDetails;
            return $uploadedDetails;
        }  
    }
    
    
    public function editProfile()
    {
        
        if($this->checkLogin())
        {
            
        if(isset($_FILES['profile_image'])) 
        {
          $pic=$this->profile_pic_update();
          $data=array('profile_pic'=>$pic,'profile_status'=>$this->input->post('profile_status'),'about_me'=>$this->input->post('profile_about')); 
        }
        else
        {
        $data=array('profile_status'=>$this->input->post('profile_status'),'about_me'=>$this->input->post('profile_about'));      
        }

        $this->db->where('id', $_SESSION['user_id']);
        $this->db->update('samajic_users', $data);
        if($this->db->affected_rows()>0)
        {
            $_SESSION['profile_status']=$this->input->post('profile_status');
            $_SESSION['about_me']=$this->input->post('profile_about');
            redirect(base_url().'index.php/User/profile');
        } 
            
        }
        else
        {
         $this->output->set_content_type('application/json')->set_output(json_encode(array('err'=>'Authentication error')));    
        }

    }
    
    
    public function profile_pic_update()
    {
        $rand=time();    
        $configUpload['upload_path']    = './assets/img/uploads/';       
        $configUpload['allowed_types']  = 'gif|jpg|png|bmp|jpeg';       
        $configUpload['file_name']  = md5($rand.$_SESSION['first_name']);
        $configUpload['file_ext']       = '.jpg';                         
        $configUpload['max_size']       = '2048';                         
        $configUpload['max_width']      = '0';                          
        $configUpload['max_height']     = '0';                         
        $this->load->library('upload', $configUpload);       
        if(!$this->upload->do_upload('profile_image'))
        {
            $uploadedDetails    = $this->upload->display_errors();
        }
        else
        {
            $uploadedDetails    = $this->upload->data('file_name');
            //echo $uploadedDetails;
            unlink("assets/img/uploads/" . $_SESSION['profile_pic']);
            $_SESSION['profile_pic']=$uploadedDetails;
            return $uploadedDetails;
        }  
    }
    
    
    public function returnJson($array)
    {
        $this->output->set_content_type('application/json')->set_output(json_encode($array));
    }
    
    public function  logout()
    {
        $this->session->sess_destroy();
        redirect('User');
    }
    
    public function show404()
    {
        $this->load->view('404/index');
    }
    
    
}
