<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forgotpwd extends CI_Controller 
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    
    public function __construct()
    {
        parent::__construct();
        $this->load->library('sendmail');
    }
    
	public function index()
	{
    $this->load->view('User/forgotpwd');
	}
    
    public function rst()
    {
    $this->_forgotPassword($this->input->post('email'));
/*    if(!empty($mail_key))
    {
     $data['hash']=$mail_key;
     $this->load->view('user/resetpwd',$data);   
    }
    else
    {
     redirect(base_url());  
    }  */
    }
    
    private function _forgotPassword($email)
    {
    
    $query=$this->db->get_where('samajic_users',array('email'=>$email));
    if($query->num_rows()>0)
    {
    $hash=hash('ripemd320', $email);
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: Auto-mailer<donotreply@samajic.in>'."\r\n";
    $message = "
    <html>
    <head>
    <title>Samajic - Reset Password</title>
    </head>
    <body>
    <p>Please reset your password by clicking the below link:</p>
    <p style='font-size:18px;color:blue;'><a target='_blank' href='http://www.samajic.in/index.php/forgotpwd/pwdreset/".$hash."'>Click Here</a></p>
    </body>
    </html>
    ";
        $data=array(
                    'id'=>'',
                    'status'=>0,
                    'email'=>$email,
                    'hash'=>$hash
                   );
        $query=$this->db->insert('samajic_resetpwd',$data);   
        $send=mail($email,'Samajic - Reset Password',$message,$headers);   
        //$send=$this->sendmail->send($email,'Samajic - Reset Password',$message,'donotreply@samajic.in');
        
        if($send)
        {
        echo 'Please check your inbox.';    
        }
        else
        {
        echo 'Error sending the mail, please try again.';
        }
        
    }
    else
    {
      redirect(base_url().'index.php/forgotpwd/?err=Your email id is not registered with us');     
    }    

    }
    
    public function pwdreset($key='')
    {
       if(!empty($key))
       {
         $check_key = $this->db->get_where('samajic_resetpwd',array('hash'=>$key,'status'=>0))->row_array();   
         if(count($check_key)>0)
         {
             $data['hash']=$key;
             $this->load->view('User/resetpwd',$data);  
         }
         else
         {
             echo 'The link has been expired.';    
         }
          
       }
        else
        {
         redirect(base_url());  
        }
    }
    
    public function changepwd()
    {
        $password=$this->input->post('password');
        $key=$this->input->post('key');
        //print_r($this->input->post());exit;
        $get_email = $this->db->get_where('samajic_resetpwd',array('hash'=>$key,'status'=>0))->row_array();

        if(isset($get_email['email']))
        {
        $data=array('password'=>md5($password));
        $this->db->update('samajic_users',$data,array('email'=>$get_email['email']));
        //$query=$this->db->query('UPDATE samajic_users SET password = "'.md5($password).'" where email="'.$get_email['email'].'"');   
        $result = $this->db->affected_rows();  
        if($result > 0)
        {
            echo 'Password has been changed successfully';
            $data=array('status'=>1);
            $this->db->update('samajic_resetpwd',$data,array('hash'=>$key));
        }
        else
        {
            echo 'Please enter a different password.';
        }

        }
        else
        {
            echo 'The link has been expired.';    
        }
        
    }

}
